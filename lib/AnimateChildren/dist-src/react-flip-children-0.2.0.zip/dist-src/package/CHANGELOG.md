# react-flip-children

## 0.2.0

### Minor Changes

- Added more props and improve deletion animation performance

## 0.1.3

### Patch Changes

- change default of `useAbsolutelyPositionedForDeletedElements` into false

## 0.1.2

### Patch Changes

- fix build error

## 0.1.0

### Minor Changes

- added stagger animation

### Patch Changes

- added prop to choose rect saving strategy (either use offset or getClientBoundingRect)

## 0.0.12

### Patch Changes

- 5379275: added props to control delete animation behavior

## 0.0.11

### Patch Changes

- fix deps

## 0.0.10

### Patch Changes

- fix deps & tsconfig

## 0.0.9

### Patch Changes

- fix deps

## 0.0.8

### Patch Changes

- fix dependency

## 0.0.7

### Patch Changes

- Fix dependencies

## 0.0.6

### Patch Changes

- Update readme
